<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Backend\\Providers\\BackendServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Backend\\Providers\\BackendServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);