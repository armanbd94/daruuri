<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Frontend\\Providers\\FrontendServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Frontend\\Providers\\FrontendServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);