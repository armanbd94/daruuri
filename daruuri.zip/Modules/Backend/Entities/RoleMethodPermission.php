<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class RoleMethodPermission extends Model
{
    protected $fillable = [];
}
