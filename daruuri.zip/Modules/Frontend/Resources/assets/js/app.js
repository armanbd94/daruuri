window.Popper = require('popper.js').default;
window.$ = window.jQuery = require('jquery');

require('bootstrap');
require('../../../../../resources/asset/js/frontend/menuzord/js/menuzord');
