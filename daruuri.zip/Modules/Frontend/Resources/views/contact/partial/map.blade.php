<section>
    <div class="container-fluid pt-0 pb-0">
        <div class="row">
            <div class="col-md-12">
                {!! config('settings.google_map_iframe') !!}
            </div>
        </div>
    </div>
</section>