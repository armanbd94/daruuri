<section class="">
    <div class="container-fluid p-0">
        <div class="section-content">
            <div class="row">
                <div class="col-sm-12">
                    <div class="tm-sc tm-sc-custom-columns-holder tm-cc-two-columns tm-cc-responsive-mode-1280">
                        <div class="tm-sc tm-sc-custom-columns-holder-item section-typo-light bg-theme-colored2 bg-img-right"
                            data-item-class="bconsul-mascot-custom-columns-479103"
                            data-1200-up="70px 10% 70px 10%"
                            data-1199-down="90px 10% 90px 10%">
                            <div class="item-inner">
                                <div class="item-content bconsul-mascot-custom-columns-479103">
                                    <h2 class="mt-md-30">Reliable Profession and High Quality Parts</h2>
                                    <p>We have reliable profession and high quality parts. Since our experience is about 5 years, </p>
                                    <div class="row">
                                        
                                        <div class="col-md-12 col-lg-12">
                                            <div class="tm-sc tm-sc-progress-bar progress-bar-fixed-right-percent mt-30 mb-40"
                                                data-percent="100" data-unit-left="" data-unit-right="%"
                                                data-bar-height="" data-barcolor="bg-theme-colored1">
                                                <div class="progress-title-holder">
                                                    <h6 class="pb-title">Customer satisfaction</h6>
                                                    <span class="percent"><span class="symbol-left"></span><span
                                                            class="value">100</span><span
                                                            class="symbol-right">%</span></span>
                                                </div>
                                                <div class="progress-holder">
                                                    <div class="progress-content"></div>
                                                </div>
                                            </div>
                                            <div class="tm-sc tm-sc-progress-bar progress-bar-fixed-right-percent mb-40"
                                                data-percent="100" data-unit-left="" data-unit-right="%"
                                                data-bar-height="" data-barcolor="bg-theme-colored1">
                                                <div class="progress-title-holder">
                                                    <h6 class="pb-title">On Time Delivery</h6>
                                                    <span class="percent"><span class="symbol-left"></span><span
                                                            class="value">100</span><span
                                                            class="symbol-right">%</span></span>
                                                </div>
                                                <div class="progress-holder">
                                                    <div class="progress-content"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tm-sc tm-sc-custom-columns-holder-item"
                            data-item-class="bconsul-mascot-custom-columns-363166">
                            <div class="item-inner">
                                <div class="item-content charingo-mascot-custom-columns-872139 p-0">
                                    <div id="twentytwenty-slider-516457"
                                        class="twentytwenty-container tm-sc tm-sc-before-after-slider text-center"
                                        data-orientation="horizontal" data-offset-percent="0.5"
                                        data-no-overlay="true" data-before-label="" data-after-label="">
                                        <img src="images/bg/ab1.jpg" alt="Image"> <img src="images/bg/ab2.jpg"
                                            alt="Image"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
