<section class="layer-overlay overlay-theme-colored2-9 section-typo-light text-center"
        data-tm-bg-img="images/privacy-policy-4-2.jpg">
        <div class="container">
            <div class="section-content">
                <div class="row">

                </div>
            </div>
        </div>
    </section>