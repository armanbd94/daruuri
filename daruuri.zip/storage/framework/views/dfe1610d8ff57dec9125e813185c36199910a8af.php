<section class="bg-img-no-repeat bg-img-right" data-tm-bg-img="images/bg/bg-shape-bconsul2.png">
    <div class="container <?php echo e($padding ?? ''); ?>">
        <div class="section-content">
            <div class="row">
                <div class="col-sm-12 col-lg-6 col-md-12">
                    <img src="storage/<?php echo e(PAGE.$about->image); ?>" class="attachment-full" alt="<?php echo e($about->title); ?>" />
                </div>
                <div class="col-xl-6 col-lg-6">
                    <h2 class="font-size-54"><?php echo e($about->title); ?></h2>

                    <p><?php echo e($about->description); ?></p>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\daruuri\resources\views/components/frontend/about.blade.php ENDPATH**/ ?>