<div class="kt-aside-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_aside_menu_wrapper">
    <div id="kt_aside_menu" class="kt-aside-menu " data-ktmenu-vertical="1" data-ktmenu-scroll="1" data-ktmenu-dropdown-timeout="500">

        <ul class="kt-menu__nav ">
        <?php $__currentLoopData = Session::get('permitted_modules'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($menu->children->isEmpty()): ?>
            <li class="kt-menu__item  
            <?php if(Request::is('admin') && $menu->module_link == '/'): ?>
                <?php echo e('kt-menu__item--active'); ?>

            <?php endif; ?>
            <?php echo e(Request::is('admin'.'/'.$menu->module_link) ? 'kt-menu__item--active' : ''); ?>" aria-haspopup="true">
                    <a href="<?php echo e(url('admin'.'/'.$menu->module_link)); ?>"
                    class="kt-menu__link "><span class="kt-menu__link-icon"><i class="<?php echo e($menu->module_icon); ?>"></i></span>
                    <span class="kt-menu__link-text"><?php echo e($menu->module_name); ?></span>
                </a>
            </li>
            <?php else: ?> 
            <li class="kt-menu__item  kt-menu__item--submenu 
            <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Request::is('admin'.'/'.$submenu->module_link) ? 'kt-menu__item--open' : ''); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            " aria-haspopup="true" data-ktmenu-submenu-toggle="hover">
                <a  href="javascript:void(0);" class="kt-menu__link kt-menu__toggle">
                    <span class="kt-menu__link-icon"><i class="<?php echo e($menu->module_icon); ?>"></i></span>
                    <span class="kt-menu__link-text"><?php echo e($menu->module_name); ?></span>
                    <i class="kt-menu__ver-arrow la la-angle-right"></i>
                </a>
                <div class="kt-menu__submenu "><span class="kt-menu__arrow"></span>
                    <ul class="kt-menu__subnav">
                        <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="kt-menu__item <?php echo e(Request::is('admin'.'/'.$submenu->module_link) ? 'kt-menu__item--active' : ''); ?>" aria-haspopup="true">
                            <a  href="<?php echo e(url('admin',$submenu->module_link)); ?>" class="kt-menu__link ">
                                <span class="kt-menu__link-icon"><i class="<?php echo e($submenu->module_icon); ?>"></i></span>
                                <span class="kt-menu__link-text"><?php echo e($submenu->module_name); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>
</div>
<?php /**PATH C:\laragon\www\daruuri\resources\views/components/backend/sidebar.blade.php ENDPATH**/ ?>