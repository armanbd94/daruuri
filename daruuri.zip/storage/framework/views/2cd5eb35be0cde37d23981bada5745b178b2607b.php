<div class="row pt-5">
    <div class="col-md-12 text-center pb-5">
        <h3 style="margin: 0;">Services for <span style="color: #1bacd6;"><?php echo e($phones->phone_name); ?></span></h3>
        <span>You feel it's expensive? just give us a call for best prices : <b style="color: #1bacd6;"><?php echo e(config('settings.contact_number')); ?></b></span>
    </div>
    <?php if($phones->count()): ?>
        <?php $__currentLoopData = $phones->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="services-style-four col-md-3 col-sm-6 col-xs-12">
                <div class="inner-box text-center">
                    <div class="icon-box">
                        <img style="width: 50px;" src="storage/<?php echo e(SERVICE_ICON.$service->service_icon); ?>" alt="<?php echo e($service->service_name); ?>" />
                    </div>
                    <h5><?php echo e($service->service_name); ?></h5>
                    <p><?php echo e(config('settings.currency_symbol').$service->pivot->price); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
</div><?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/phone-service.blade.php ENDPATH**/ ?>