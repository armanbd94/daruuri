

<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link href="css/bootstrap-select.css" rel="stylesheet" type="text/css" />
<style>
.bootstrap-select{
    border-radius: 5px !important;
}
#showDataModal .modal-dialog{
    width: 90% !important;
    margin: 1.75rem auto;
}
.modal-dialog{
    max-width: 90% !important;
}
.services-style-four {
    padding: 0px 25px;
    position: relative;
    margin-bottom: 50px;
}
.services-style-four .inner-box {
    position: relative;
    padding: 30px 30px 25px;
    border: 1px solid #e0e0e0;
}
.services-style-four .inner-box .icon-box {
    position: absolute;
    left: 40%;
    top: -35px;
    width: 70px;
    height: 70px;
    line-height: 66px;
    border-radius: 50%;
    text-align: center;
    border: 1px solid #e0e0e0;
    background-color: #ffffff;
}
@media  only screen and (max-width: 325px) {
    .services-style-four .inner-box .icon-box {
        left: 35%;
    }
}
@media  only screen and (min-width: 326px) {
    .services-style-four .inner-box .icon-box {
        left: 40%;
    }
}

.services-style-four .inner-box h5 {
    font-size: 14px;
    font-weight: 600;
    margin: 15px 0 0 0;
    text-transform: uppercase;
}
.services-style-four .inner-box p {
    font-size: 14px;
    font-weight: 600;
    margin: 0;
    padding: 0;
}

.service-modal-section{
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.7);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999999;
    padding-top: 50px;
}
#service_modal{
    width: 90vw;
    margin: 0 auto;
}
#close_btn{
    width: 30px;
    height: 30px;
    font-size: 15px;
    cursor: pointer;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">

    <!-- Section: Banner -->
    <?php echo $__env->make('frontend::banner.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php if (isset($component)) { $__componentOriginal3dce379b57bc17ff8a3a4e96e8d820fc87633d2c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\SearchForm::class, []); ?>
<?php $component->withName('frontend.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3dce379b57bc17ff8a3a4e96e8d820fc87633d2c)): ?>
<?php $component = $__componentOriginal3dce379b57bc17ff8a3a4e96e8d820fc87633d2c; ?>
<?php unset($__componentOriginal3dce379b57bc17ff8a3a4e96e8d820fc87633d2c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <!-- Section: Service -->
    <section>
        <div class="container pb-70">
            <div class="section-content">
                <?php if($services->count()): ?>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row pb-5">
                        <div class="col-xs-12 col-sm-12 col-md-12 pull-left flip">
                            <div class="row">
                                <div class="col-md-12">
                                    <img alt="<?php echo e($service->title); ?>" src="storage/<?php echo e(PAGE.$service->image); ?>" style="width: 100%;border: 5px solid #1bacd6;
                                    box-shadow: 0px 3px 7px rgba(0,0,0,0.5);">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="mt-20 mb-10"><?php echo e($service->title); ?></h3>
                                    <p><?php echo e($service->description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>
    </section>

    <?php echo $__env->make('frontend::modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
 <script src="js/backend/bootstrap-select.js" type="text/javascript"></script>
 <script type="text/javascript">
    var _token = "<?php echo e(csrf_token()); ?>";
    $(document).on('change','#phone_id', function(){
        let phone_id = $("#phone_id").val();
        if(phone_id){
            $(".error").each(function () {
                $(this).empty();//remove error text
            });
            $("#searchDataForm").find('.is-invalid').removeClass('is-invalid');
        }else{
            $("#phone_id").parent().addClass('is-invalid');
            $("#phone_id").parent().after('<div class="error invalid-feedback"><i class="icon fas fa-question-circle"></i> Please choose a phone</div>');
        }       
    });
    $(document).on('click','#search-btn', function(){
        let brand_id = $("#brand_id").val();
        let phone_id = $("#phone_id").val();
        if(brand_id){
            $(".error").each(function () {
                    $(this).empty();//remove error text
                });
                $("#searchDataForm").find('.is-invalid').removeClass('is-invalid');
            if(phone_id){
                $(".error").each(function () {
                    $(this).empty();//remove error text
                });
                $("#searchDataForm").find('.is-invalid').removeClass('is-invalid');
                $.ajax({
                    url: "<?php echo e(route('phone.services')); ?>",
                    type: "POST",
                    data:{phone_id:phone_id,_token:_token},
                    dataType: "JSON",
                    success: function (data) {
                        $('.service-modal-section').removeClass('d-none');
                        $('.service-modal-section .card-body').html('');
                        $('.service-modal-section .card-body').html(data);
                        $('.selectpicker').val('').selectpicker('refresh');
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            }else{
                $("#phone_id").parent().addClass('is-invalid');
                $("#phone_id").parent().after('<div class="error invalid-feedback"><i class="icon fas fa-question-circle"></i> Please choose a phone</div>');
            }
        }else{
            $("#brand_id").parent().addClass('is-invalid');
            $("#brand_id").parent().after('<div class="error invalid-feedback"><i class="icon fas fa-question-circle"></i> Please choose a brand</div>');
        }
        
    });
    function getPhoneList(brand_id){
        if(brand_id){
            $(".error").each(function () {
                    $(this).empty();//remove error text
                });
                $("#searchDataForm").find('.is-invalid').removeClass('is-invalid');
            $.ajax({
                url: "<?php echo e(route('brand.phone.list')); ?>",
                type: "POST",
                data:{brand_id:brand_id,_token:_token},
                dataType: "JSON",
                success: function (data) {
                    $('#phone_id').html('');
                    $('#phone_id').html(data);
                    $('#phone_id.selectpicker').selectpicker('refresh');
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                }
            });
        }
    }

    function hide_modal(){
        $('.service-modal-section').addClass('d-none');
    }

 </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/service/service.blade.php ENDPATH**/ ?>