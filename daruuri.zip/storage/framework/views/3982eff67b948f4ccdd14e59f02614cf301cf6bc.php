<section class="overlay-theme-colored2-9 container-fluid bg-theme-colored2" style="width: 100%;" data-tm-bg-img="images/search-form-bg.jpg">
    <div class="container py-5">
        <h6 class="text-white">Repair Cost For Your Smartphone</h6>
        <form method="POST" id="searchDataForm">
            <?php echo csrf_field(); ?>
            <div class="row">
                
                <div class="form-group col-md-5">
                    <select required name="brand_id" id="brand_id" onchange="getPhoneList(this.value)" class="form-control selectpicker" data-live-search="true" data-live-search-placeholder="Search" title="Choose a Brand">
                        <option value="">Select a Brand</option>
                        <?php if($brands->count()): ?>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-md-5">
                    <select required name="phone_id" id="phone_id" class="form-control selectpicker" data-live-search="true" data-live-search-placeholder="Search" title="Choose a Phone">
                        <option value="">Select a Phone</option>
                    </select>
                </div>
                <div class="form-group col-md-2">
                    <button type="button"
                        class="wpcf7-form-control wpcf7-submit btn btn-theme-colored1 btn-round" id="search-btn">Go for it <i class="fas fa-arrow-circle-right"></i></button>
                </div>
            </div>
        </form>
    </div>
</section><?php /**PATH C:\laragon\www\daruuri\resources\views/components/frontend/search-form.blade.php ENDPATH**/ ?>