<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <base href="<?php echo e(asset('/')); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="title" content="<?php echo e(config('settings.seo_meta_title')); ?>"/>
    <meta name="description" content="<?php echo e(config('settings.seo_meta_description')); ?>"/> 
    <meta name="robots" content="index, follow">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('settings.site_title') ?? env('APP_NAME')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="storage/<?php echo e(LOGO.config('settings.site_favicon')); ?>" />

    <!-- Stylesheet -->
    <link href="css/fontawesome.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(mix('css/frontend.css')); ?>" rel="stylesheet">
    <link href="css/frontend/javascript-plugins-bundle.css" rel="stylesheet" />
    <?php echo $__env->yieldPushContent('style'); ?>
    <style>
    /* :: 4.0 Preloader Area CSS */
    #preloader {
      overflow: hidden;
      height: 100%;
      left: 0;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 100000000;
      background-color: #fff;
      display: table;
    }

    #preloader #loading {
      display: table-cell;
      vertical-align: middle;
      text-align: center;
    }

    #preloader #loading img {
      width: 100px;
      -webkit-animation: 1500ms linear 0s normal none infinite running south-load;
      animation: 1500ms linear 0s normal none infinite running south-load;
    }
    @-webkit-keyframes south-load {
      0% {
        -webkit-transform: rotateY(0deg);
        transform: rotateY(0deg);
      }

      100% {
        -webkit-transform: rotate(360deg);
        transform: rotateY(360deg);
      }
    }

    @keyframes  south-load {
      0% {
        -webkit-transform: rotate(0deg);
        transform: rotateY(0deg);
      }

      100% {
        -webkit-transform: rotate(360deg);
        transform: rotateY(360deg);
      }
    }
    </style>
</head>

<body class="container-1340px">
    <!-- BEGIN:: PRELOADER -->
    <div id="preloader">
        <div id="loading">
            <img src="images/daruuri.png" style="width: 70px;" alt="loading..."  />
        </div>
    </div>
    <!-- END:: PRELOADER -->
    <div id="wrapper" class="clearfix">
        <!-- Header -->
        <?php if (isset($component)) { $__componentOriginalfdb0fe874234de8309d46b3e522a7fb126f16d0c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\Header::class, []); ?>
<?php $component->withName('frontend.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfdb0fe874234de8309d46b3e522a7fb126f16d0c)): ?>
<?php $component = $__componentOriginalfdb0fe874234de8309d46b3e522a7fb126f16d0c; ?>
<?php unset($__componentOriginalfdb0fe874234de8309d46b3e522a7fb126f16d0c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

        <!-- Start main-content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- end main-content -->

        <!-- Footer -->
         <?php if (isset($component)) { $__componentOriginalcf1b38e24f6313691245ea870737e9b955d012cb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\Footer::class, []); ?>
<?php $component->withName('frontend.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf1b38e24f6313691245ea870737e9b955d012cb)): ?>
<?php $component = $__componentOriginalcf1b38e24f6313691245ea870737e9b955d012cb; ?>
<?php unset($__componentOriginalcf1b38e24f6313691245ea870737e9b955d012cb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

        <a class="scrollToTop" href="javascript:void(0);"><i class="fa fa-angle-up"></i></a>
    </div>
     <!-- external javascripts -->
     <script src="js/frontend.js"></script>
     <script src="js/frontend/javascript-plugins-bundle.js"></script>
     <!-- JS | Custom script for all pages -->
     <script src="js/frontend/custom.js"></script>
     <?php echo $__env->yieldPushContent('script'); ?>
     <script>
        var $window = $(window);

        // :: Preloader Active Code
        $window.on('load', function () {
            $('#preloader').fadeOut('slow', function () {
                $(this).remove();
            });
        });
     </script>
</body>

</html>
<?php /**PATH C:\laragon\www\daruuri\resources\views/frontend/master.blade.php ENDPATH**/ ?>