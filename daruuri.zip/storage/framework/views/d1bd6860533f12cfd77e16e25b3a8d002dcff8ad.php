<?php if($products->count()): ?>
    <div class="col-md-12 pb-5">
        <?php if(!empty($phone)): ?>
        <h4 class="text-left" style="color: #1bacd6;font-weight:bold;">
            Search Result for <b class="text-danger">"<?php echo e($phone); ?>"</b>
        </h4>
        <?php endif; ?>
        <?php if(!empty($brand_name)): ?>
        <h4 class="text-left" style="color: #1bacd6;font-weight:bold;">
            Filter Result for <b class="text-danger">"<?php echo e($brand_name); ?>"</b>
        </h4>
        <?php endif; ?>
        <b>Showing <?php echo e($products->firstItem()); ?> to <?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?> result</b>
    </div>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="product-card">
                <div class="img-box">
                    <img src="storage/<?php echo e(PRODUCT.$product->product_image); ?>" alt="<?php echo e($product->product_name); ?>">
                </div>
                <div class="content">
                    <h4><?php echo e($product->product_name); ?></h4>
                    <span class="badge badge-pill badge-primary"><?php echo e($product->brand->brand_name); ?></span>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12 pt-3" style="padding-left: 5px !important;padding-right:5px !important;">
       <?php echo e($products->onEachSide(1)->links()); ?>

    </div>
<?php else: ?>
<div class="col-md-12">
    <h4 class="text-center text-danger">No Product Found</h4>
</div>
<?php endif; ?>




<?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/product/list.blade.php ENDPATH**/ ?>