<div class="service-modal-section d-none" >
    <div class="card" id="service_modal">
        <div class="card-header" style="background: #1bacd6;">
          <button class="btn-danger text-white float-right" id="close_btn" onclick="hide_modal()">X</button>
        </div>
        <div class="card-body">

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/modal.blade.php ENDPATH**/ ?>