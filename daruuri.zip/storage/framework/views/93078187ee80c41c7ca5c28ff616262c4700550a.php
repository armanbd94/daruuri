<section>
    <div class="container pt-90">
        <div class="section-title">
            <div class="row justify-content-md-center">
                <div class="col-md-8">
                    <div class="text-center mb-60">
                        <div
                            class="tm-sc tm-sc-section-title section-title section-title-style1 text-center line-bottom-style4-attached-double-lines1">
                            <div class="title-wrapper">
                                <h2 class="title"> <span class="">Our </span> <span
                                        class="text-theme-colored1">Recent</span> Products</h2>
                                <div class="title-seperator-line"></div>
                                <div class="paragraph">
                                    <p>See Our Recent Products</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-content">
            <div class="row">
                <?php if($data['products']->count()): ?>
                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="product-card">
                        <div class="img-box">
                            <img src="storage/<?php echo e(PRODUCT.$product->product_image); ?>" alt="<?php echo e($product->product_name); ?>">
                        </div>
                        <div class="content">
                            <h4><?php echo e($product->product_name); ?></h4>
                            <span class="badge badge-pill badge-primary"><?php echo e($product->brand->brand_name); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/home/product/product.blade.php ENDPATH**/ ?>