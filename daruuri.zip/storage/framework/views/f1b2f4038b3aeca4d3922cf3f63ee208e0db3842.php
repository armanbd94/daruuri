

<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">

    <!-- Section: Banner -->
    <?php echo $__env->make('frontend::banner.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <!-- Section: About -->
      <?php if (isset($component)) { $__componentOriginal30ce241ad31a2467f63f9a87bab0d983ef5c1cba = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Frontend\About::class, []); ?>
<?php $component->withName('frontend.about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal30ce241ad31a2467f63f9a87bab0d983ef5c1cba)): ?>
<?php $component = $__componentOriginal30ce241ad31a2467f63f9a87bab0d983ef5c1cba; ?>
<?php unset($__componentOriginal30ce241ad31a2467f63f9a87bab0d983ef5c1cba); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <!-- Section: How We Works -->
    <?php echo $__env->make('frontend::home.how-we-works.how-we-works', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\daruuri\Modules/Frontend\Resources/views/about/about.blade.php ENDPATH**/ ?>