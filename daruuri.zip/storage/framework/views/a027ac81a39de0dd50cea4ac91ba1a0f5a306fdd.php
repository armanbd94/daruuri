<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-footer__copyright">
        <?php echo e(date('Y')); ?>&nbsp;&copy;&nbsp;<a href="http://keenthemes.com/metronic" target="_blank" class="kt-link"><?php echo e(env('APP_NAME')); ?></a>
    </div>
</div><?php /**PATH C:\laragon\www\daruuri\resources\views/backend/include/footer.blade.php ENDPATH**/ ?>