<header id="header" class="header header-layout-type-header-2rows">
    
    <div class="header-nav">
        <div class="header-nav-wrapper navbar-scrolltofixed green">
            <div class="menuzord-container header-nav-container green ">
                <div class="container position-relative">
                    <div class="row">
                        <div class="col">
                            <div class="row header-nav-col-row">
                                <div class="col-sm-auto align-self-center">
                                    <a class="menuzord-brand site-brand" href="index-mp-layout1.html">
                                        <img class="logo-default logo-1x" src="storage/<?php echo e(LOGO.config('settings.site_logo')); ?>" alt="Logo">
                                        <img class="logo-default logo-2x retina" src="storage/<?php echo e(LOGO.config('settings.site_logo')); ?>"
                                            alt="Logo">
                                    </a>
                                </div>
                                <div class="col-sm-auto ml-auto pr-0 align-self-center">
                                    <nav id="top-primary-nav" class="menuzord green" data-effect="fade"
                                        data-animation="none" data-align="right">
                                        <ul id="main-nav" class="menuzord-menu">
                                            <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li class="<?php echo e((request()->is('about')) ? 'active' : ''); ?>"><a href="<?php echo e(route('about')); ?>">About</a></li>
                                            <li class="
                                            <?php if($categories->count()): ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e((request()->is("product/{$category->category_slug}")) ? 'active' : ''); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>"><a href="javascript:void(0);">Product</a>
                                                <ul class="dropdown">
                                                    <?php if($categories->count()): ?>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="<?php echo e(route('product',['category' => $category->category_slug])); ?>"><?php echo e($category->category_name); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </ul>
                                            </li>
                                            <li class="<?php echo e((request()->is('service')) ? 'active' : ''); ?>"><a href="<?php echo e(route('service')); ?>">Service</a></li>
                                            <li  class="<?php echo e((request()->is('faqs')) ? 'active' : ''); ?> <?php echo e((request()->is('feedback')) ? 'active' : ''); ?>">
                                                <a href="javascript:void(0);">Support</a>
                                                <ul class="dropdown">
                                                    <li><a href="<?php echo e(route('faqs')); ?>">FAQs</a></li>
                                                    <li><a href="<?php echo e(route('feedback')); ?>">Feedback</a></li>
                                                </ul>
                                            </li>
                                            <li class="<?php echo e((request()->is('contact')) ? 'active' : ''); ?>"><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="row d-block d-xl-none">
                                <div class="col-12">
                                    <nav id="top-primary-nav-clone"
                                        class="menuzord d-block d-xl-none default menuzord-color-default menuzord-border-boxed menuzord-responsive"
                                        data-effect="slide" data-animation="none" data-align="right">
                                        <ul id="main-nav-clone"
                                            class="menuzord-menu menuzord-right menuzord-indented scrollable">
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\laragon\www\daruuri\resources\views/components/frontend/header.blade.php ENDPATH**/ ?>